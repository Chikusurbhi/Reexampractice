package com.capgemini.takehome.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capegemini.takehome.dao.IProductDAO;
import com.capegemini.takehome.dao.ProductDAO;
import com.capgemini.takehome.bean.Product;

public class ProductService implements IProductService {
	IProductDAO product = new ProductDAO();

	@Override
	public Product getProductDetails(int product_code) {
		// TODO Auto-generated method stub
		if (codevalidation(product_code)) {
			return product.getProductDetails(product_code);
		} else
			System.out.println("Product code should be of 4 digits");
		return null;
	}

	private boolean codevalidation(int product_code) {
		// TODO Auto-generated method stub
		Pattern pat = Pattern.compile("[0-9]{4}");
		String s1 = Integer.toString(product_code);
		// System.out.println(s1+"abcd");
		Matcher mat = pat.matcher(s1);
		return mat.matches();
	}

	public boolean QuantityValidation(int qty) {
		if (qty <= 0)
			return false;
		else
			return true;

	}

}
