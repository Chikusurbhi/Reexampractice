package com.capegemini.takehome.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.util.CollectionUtil;

public class ProductDAO implements IProductDAO{

	Map<Integer,Product> products= new HashMap<Integer, Product>();
	CollectionUtil collection= new CollectionUtil();
	@Override
	public Product getProductDetails(int product_code) {
		// TODO Auto-generated method stub
		products= collection.getList();
		for(Map.Entry<Integer,Product> product: products.entrySet())
		{
			if(product.getKey()==product_code)
			{
			  return products.get(product.getKey());	
			}
				
		}
		System.out.println("Product code doesn't exists");
		return null;
	}

}
