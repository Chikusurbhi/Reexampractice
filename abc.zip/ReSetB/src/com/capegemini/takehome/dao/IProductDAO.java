package com.capegemini.takehome.dao;

import com.capgemini.takehome.bean.Product;

public interface IProductDAO {
	Product getProductDetails(int product_code);
}
