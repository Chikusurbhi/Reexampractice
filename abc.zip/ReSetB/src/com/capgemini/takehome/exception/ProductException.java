package com.capgemini.takehome.exception;

public class ProductException extends Exception {

}
