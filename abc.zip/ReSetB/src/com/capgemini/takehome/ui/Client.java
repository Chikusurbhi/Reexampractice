package com.capgemini.takehome.ui;

import java.util.Scanner;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.exception.ProductException;
import com.capgemini.takehome.service.IProductService;
import com.capgemini.takehome.service.ProductService;

public class Client {
	static IProductService service = new ProductService();
	static Product product;

	public static void main(String[] args) throws ProductException {

		Scanner scanner = new Scanner(System.in);
		int x;
		System.out.println("1.Generate Bill by entering Product code and quantity");
		System.out.println("2.Exit");
		System.out.println("Enter your choice");
		int choice = scanner.nextInt();
		int flag = 0;
		do {
		switch (choice) {
		case 1: {
			     int pc = 0;

			     System.out.println("Enter the product code (Integer value only)");
			     pc = scanner.nextInt();
			     product = service.getProductDetails(pc);

			     
			     if(product==null)
			    	 throw new ProductException();
			    	 
			     System.out.println("Enter the product qunatity");
			     int qty = scanner.nextInt();
			     
			     if (new ProductService().QuantityValidation(qty)) {

				 flag = 1;
			     }
			    if (flag == 1) {
				System.out.println("Product Name:" + product.getProduct_name());
				System.out.println("Product Category:" + product.getProduct_category());
				System.out.println("Product Price:" + product.getProduct_price());
				System.out.println("Quantity:" + qty);
				System.out.println("Line total(Rs):" + product.getProduct_price() * qty);

			    } else
				 System.out.println("Quantity is not valid");

		        }
		        break;
		case 2: System.exit(0);
		        break;
		default:System.out.println("Wrong Choice");

		}
		x=scanner.nextInt();
	}while(x!=2);
	}
}