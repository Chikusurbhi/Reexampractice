import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capegemini.takehome.dao.IProductDAO;
import com.capegemini.takehome.dao.ProductDAO;
import com.capgemini.takehome.bean.Product;

public class TestKaro {
IProductDAO daoRef;
	@Before
	public void before()
	{
		daoRef=new ProductDAO();
		
	}
	
	
	
	@Test
	public void test() {
	Product p=	daoRef.getProductDetails(1003);
		assertFalse(p.getProduct_name().equals("Telescope"));
		
		
	}
	
	
	
	@After
	public void after()
	{
		
		daoRef=null;
	}
}
